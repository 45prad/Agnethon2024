<!DOCTYPE html>

  <head>    
    <link rel="stylesheet" href="../styles.css">
  </head>
  <body class="bg-dark"> 

   <div class="main">
    <div class="container">
    

    <div class="card">
      <div class="box">
        <div class="content">
          <h4>OUTREACH PROGRAM</h4>
          <p>details</p>
          <a href="outreach/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="box">
        <div class="content">
          <h4>WORKSHOP/
            SEMINAR</h4>
          <p>conducted by faculty</p>
          <a href="workshop/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>
  </div>
</div>
        
  <?php include('../header.php'); ?>  
  </body>
</html>

