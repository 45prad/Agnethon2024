
<!DOCTYPE html>

  <head>    
    <link rel="stylesheet" href="../styles.css">
  </head>
  <body class="bg-dark"> 

  <?php include('../header.php'); ?>

   <div class="main">
    <div class="container">
    <div class="card">
      <div class="box">
        <div class="content">
          <h4>HIGHER STUDIES</h4>
          <p>higher studies details</p>
          <a href="higher studies/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="box">
        <div class="content">
          <h4>CAREER GUIDANCE</h4>
          <p>details</p>
          <a href="career_guidance/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>
    
    <div class="card">
      <div class="box">
        <div class="content">
          <h4>COMPETITIVE EXAMS</h4>
          <p>details</p>
          <a href="competitive_exams/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>

    
        
 
</div>
</div>


  </body>
</html>

