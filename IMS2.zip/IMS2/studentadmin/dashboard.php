<!DOCTYPE html>

  <head>    
    <link rel="stylesheet" href="../styles.css">
  </head>
  
  <body class="bg-dark">

   <div class="main">
   <div class="container">
    <div class="container">
    </div>
    <div class="card">
      <div class="box">
        <div class="content">
          <h4>STUDENT INTERNSHIP DETAILS</h4>
          <p>Details</p>
          <a href="internship_details/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="box">
        <div class="content">
          <h4>STUDENT ACHIEVEMENT ACTIVITIES</h4>
          <p>Details</p>
          <a href="student_achievements/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="box">
        <div class="content">
          <h4>STUDENT COURSES & WORKSHOPS</h4>
          <p>Details</p>
          <a href="courses_workshops/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="box">
        <div class="content">
          <h4>STUDENT PAPER PUBLICATION</h4>
          <p>Details</p>
          <a href="paper_publication/index.php">Go to Criteria</a>
        </div>
      </div>
    </div>
    


<?php include('../header.php'); ?> 
  </body>
</html>

